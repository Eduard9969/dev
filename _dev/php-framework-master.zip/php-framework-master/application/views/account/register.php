<h3>Регистрация</h3>
<form>
	<p>Логин</p>
	<p><input type="text"></p>
	<p>Пароль</p>
	<p><input type="text"></p>
	<b><button>Регистрация</button></b>
</form>