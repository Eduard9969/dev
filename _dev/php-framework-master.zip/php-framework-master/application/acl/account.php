<?php

return [
	'all' => [
		//
	],
	'authorize' => [
		//
	],
	'guest' => [
		'register',
		'login',
	],
	'admin' => [
		//
	],
];