<?php

return [
	'host' => '',
	'name' => '',
	'user' => '',
	'password' => '',
];