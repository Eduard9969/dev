# Introduction
Degree material design admin template is based on angular material framework. It uses gulp as a task runner, sass for organising css files,angularjs for frontend code. You can use this admin template as a starter for web apps. The template works best in all devices and mobile friendly.

## How to use
1. Clone (or download) the repo.
2. Do `npm install`.
3. Run `gulp` to start the server in development.
4. Go to http://localhost:2400.
5. Finally for production mode, run the gulp again with `gulp prod`.

## Browser Support
- All modern browsers (including IE10+,)

If you like it, then consider purchasing my premium (reactjs + bootstrap 4) admin template from themeforest : https://goo.gl/KKT4i3
